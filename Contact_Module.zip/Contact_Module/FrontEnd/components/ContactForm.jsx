import { useState } from 'react';
import axios from 'axios';
import './ContactForm.css';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    message: ''
  });

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9]{10,13}$/;

    if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
    if (!emailRegex.test(formData.email)) newErrors.email = 'Enter a valid email';
    if (!phoneRegex.test(formData.phone)) newErrors.phone = 'Phone must be 10 to 13 digits';
    if (formData.message.trim().length < 50)
      newErrors.message = 'Message must be at least 50 characters';

    return newErrors;
  };

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors(prev => ({ ...prev, [e.target.name]: '' })); // Clear error while typing
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validate();

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    const payload = {
      name: `${formData.firstName.trim()} ${formData.lastName.trim()}`,
      email: formData.email,
      phone: formData.phone,
      message: formData.message
    };

    try {
      await axios.post('http://localhost:7000/contacts', payload);
      setSubmitted(true);
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        message: ''
      });
      setErrors({});
    } catch (err) {
      alert('Something went wrong. Please try again.');
    }
  };

  return (
    <div className="form-wrapper d-flex justify-content-center align-items-center">
      <form className="contact-form p-5 rounded-4 shadow" onSubmit={handleSubmit} noValidate>
        <h2 className="text-center mb-4">Get In Touch</h2>

        <div className="row">
          <div className="col-md-6 mb-3">
            <label className="form-label">First Name <span className="text-danger">*</span></label>
            <input
              type="text"
              name="firstName"
              className={`form-control custom-input ${errors.firstName ? 'is-invalid' : ''}`}
              placeholder="First Name"
              required
              value={formData.firstName}
              onChange={handleChange}
            />
            {errors.firstName && <div className="invalid-feedback">{errors.firstName}</div>}
          </div>
          <div className="col-md-6 mb-3">
            <label className="form-label">Last Name <span className="text-danger">*</span></label>
            <input
              type="text"
              name="lastName"
              className={`form-control custom-input ${errors.lastName ? 'is-invalid' : ''}`}
              placeholder="Last Name"
              required
              value={formData.lastName}
              onChange={handleChange}
            />
            {errors.lastName && <div className="invalid-feedback">{errors.lastName}</div>}
          </div>

          <div className="col-md-6 mb-3">
            <label className="form-label">Email <span className="text-danger">*</span></label>
            <input
              type="email"
              name="email"
              className={`form-control custom-input ${errors.email ? 'is-invalid' : ''}`}
              placeholder="user@example.com"
              required
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && <div className="invalid-feedback">{errors.email}</div>}
          </div>
          <div className="col-md-6 mb-3">
            <label className="form-label">Phone <span className="text-danger">*</span></label>
            <input
              type="text"
              name="phone"
              className={`form-control custom-input ${errors.phone ? 'is-invalid' : ''}`}
              placeholder="9876543210"
              required
              value={formData.phone}
              onChange={handleChange}
            />
            {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
          </div>

          <div className="col-12 mb-3">
            <label className="form-label">Message <span className="text-danger">*</span></label>
            <textarea
              name="message"
              rows="4"
              className={`form-control custom-input ${errors.message ? 'is-invalid' : ''}`}
              placeholder="Type your message here..."
              required
              value={formData.message}
              onChange={handleChange}
            ></textarea>
            {errors.message && <div className="invalid-feedback">{errors.message}</div>}
          </div>
        </div>

        <div className="d-grid mt-3">
          <button type="submit" className="btn btn-submit">Submit</button>
        </div>

        {submitted && (
          <p className="text-success text-center mt-3">Thanks for submitting!</p>
        )}
      </form>
    </div>
  );
};

export default ContactForm;
