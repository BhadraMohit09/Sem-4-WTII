const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Contact = require('./Model/Contact'); // Updated: Import Contact model

const connectionString = 'mongodb+srv://23010101605:mohit123@cluster0.pbnz1h4.mongodb.net/DynamicEnterprise'; // 🔁 Replace with your actual Mongo URI

mongoose.connect(connectionString).then(() => {
  const app = express();

  app.use(cors());

  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(express.json()); // Required for JSON payloads

  console.log("✅ MongoDB Connected");

  // 🔹 GET All Contact Messages
  app.get('/contacts', async (req, res) => {
    try {
      const result = await Contact.find();
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 🔹 GET Single Contact Message by MongoDB _id
  app.get('/contacts/:id', async (req, res) => {
    try {
      const result = await Contact.findById(req.params.id);
      if (!result) return res.status(404).json({ message: "Contact not found" });
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // 🔹 POST (Create New Contact Message)
  app.post('/contacts', async (req, res) => {
    try {
      const contact = new Contact(req.body);
      const result = await contact.save();
      res.status(201).json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // 🔹 PATCH (Update Contact by ID)
  app.patch('/contacts/:id', async (req, res) => {
    try {
      const result = await Contact.findByIdAndUpdate(req.params.id, req.body, { new: true });
      if (!result) return res.status(404).json({ message: "Contact not found" });
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // 🔹 DELETE Contact Message by ID
  app.delete('/contacts/:id', async (req, res) => {
    try {
      const result = await Contact.findByIdAndDelete(req.params.id);
      if (!result) return res.status(404).json({ message: "Contact not found" });
      res.json({ message: "Deleted successfully", deleted: result });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // Start the server
  app.listen(7000, () => {
    console.log("🚀 Server running on http://localhost:7000");
  });

}).catch(err => {
  console.error("❌ MongoDB connection failed:", err.message);
});
